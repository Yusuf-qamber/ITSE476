# Bite Finder API

This is the **backend** for the Bite Finder project.  
It provides all the REST API endpoints for managing restaurants, menus, and comments.

## Frontend Repository

[Bite Finder Frontend](https://github.com/Sayed-Ali-GA/bite-finder-front-end)
